package udfconcatproject;
import org.apache.hadoop.hive.ql.exec.UDF;
import java.util.*;
public class conact_ws extends UDF
{
	public String evaluate (String input1, ArrayList<String> input2 ) {
		if (input1 == null && input2 == null) {
			return null;
		}
		else
		{
			String S1=input2.get(0);
			int i;
			for(i=1;i<input2.size()-1;i++)
			{
				S1=S1+input1+input2.get(i);
			}
		S1=S1+input1+input2.get(i);
		return S1;
		}
		
	}
}
